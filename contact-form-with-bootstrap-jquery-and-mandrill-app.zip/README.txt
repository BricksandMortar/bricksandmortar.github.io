A Pen created at CodePen.io. You can find this one at http://codepen.io/arranf/pen/doNzMP.

 Build a contact form with Bootstrap, jQuery and Mandrill 